# mongodb database name
DATABASE = 'take-away'
# collection where spending per customer are saved
COLLECTION = 'spend'
